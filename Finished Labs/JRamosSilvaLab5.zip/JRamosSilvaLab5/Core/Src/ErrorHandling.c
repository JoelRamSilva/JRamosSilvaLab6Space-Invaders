/*
 * ErrorHandling.c
 *
 *  Created on: Nov 6, 2024
 *      Author: joelrsilva
 */

#include "ErrorHandling.h"

void APPLICATION_ASSERT(bool value){
	if (!value) {
	    while (true) {
	    }
	}
}
